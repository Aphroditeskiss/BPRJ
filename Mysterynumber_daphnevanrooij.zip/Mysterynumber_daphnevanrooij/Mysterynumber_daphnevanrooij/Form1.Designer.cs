﻿namespace Mysterynumber_daphnevanrooij
{
    partial class Form1Droo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pgbAttemptsLeftDroo = new System.Windows.Forms.ProgressBar();
            this.gbxSetupDroo = new System.Windows.Forms.GroupBox();
            this.btnDefaultDroo = new System.Windows.Forms.Button();
            this.tbxNumberOfAttemptsDroo = new System.Windows.Forms.TextBox();
            this.tbxStopDroo = new System.Windows.Forms.TextBox();
            this.btnGoDroo = new System.Windows.Forms.Button();
            this.tbxStartDroo = new System.Windows.Forms.TextBox();
            this.lblNumberOfAttemptsDroo = new System.Windows.Forms.Label();
            this.lblStopAtDroo = new System.Windows.Forms.Label();
            this.lblStartAtDroo = new System.Windows.Forms.Label();
            this.gbxPlayDroo = new System.Windows.Forms.GroupBox();
            this.lblWrongGuessesDroo = new System.Windows.Forms.Label();
            this.pgbWrongGuessesDroo = new System.Windows.Forms.ProgressBar();
            this.lblColdDroo = new System.Windows.Forms.Label();
            this.lblHotDroo = new System.Windows.Forms.Label();
            this.tbHotColdDroo = new System.Windows.Forms.TrackBar();
            this.lblAttemptsLeftDroo = new System.Windows.Forms.Label();
            this.btnGuessDroo = new System.Windows.Forms.Button();
            this.tbxGuessDroo = new System.Windows.Forms.TextBox();
            this.lblMyGuessDroo = new System.Windows.Forms.Label();
            this.gbxInformationDroo = new System.Windows.Forms.GroupBox();
            this.rtbInformationDroo = new System.Windows.Forms.RichTextBox();
            this.btnAboutDroo = new System.Windows.Forms.Button();
            this.btnLocateDroo = new System.Windows.Forms.Button();
            this.btnCheatDroo = new System.Windows.Forms.Button();
            this.btnClearDroo = new System.Windows.Forms.Button();
            this.btnMovingPictureDroo = new System.Windows.Forms.Button();
            this.btnShowGameDroo = new System.Windows.Forms.Button();
            this.tbxEnterYourNameDroo = new System.Windows.Forms.TextBox();
            this.lblNameDroo = new System.Windows.Forms.Label();
            this.btnSubmitDroo = new System.Windows.Forms.Button();
            this.lblMadeByDroo = new System.Windows.Forms.Label();
            this.pbxYouLoseDroo = new System.Windows.Forms.PictureBox();
            this.pbxYouWinDroo = new System.Windows.Forms.PictureBox();
            this.pbxMovingPicture3Droo = new System.Windows.Forms.PictureBox();
            this.pbxMovingpicture2Droo = new System.Windows.Forms.PictureBox();
            this.pbxMovingPictureDroo = new System.Windows.Forms.PictureBox();
            this.pbxBackgroundDroo = new System.Windows.Forms.PictureBox();
            this.pbxMovingPicture4Droo = new System.Windows.Forms.PictureBox();
            this.gbxSetupDroo.SuspendLayout();
            this.gbxPlayDroo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbHotColdDroo)).BeginInit();
            this.gbxInformationDroo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYouLoseDroo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYouWinDroo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingPicture3Droo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingpicture2Droo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingPictureDroo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBackgroundDroo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingPicture4Droo)).BeginInit();
            this.SuspendLayout();
            // 
            // pgbAttemptsLeftDroo
            // 
            this.pgbAttemptsLeftDroo.ForeColor = System.Drawing.Color.Lime;
            this.pgbAttemptsLeftDroo.Location = new System.Drawing.Point(105, 113);
            this.pgbAttemptsLeftDroo.Name = "pgbAttemptsLeftDroo";
            this.pgbAttemptsLeftDroo.Size = new System.Drawing.Size(100, 13);
            this.pgbAttemptsLeftDroo.TabIndex = 9;
            // 
            // gbxSetupDroo
            // 
            this.gbxSetupDroo.Controls.Add(this.btnDefaultDroo);
            this.gbxSetupDroo.Controls.Add(this.tbxNumberOfAttemptsDroo);
            this.gbxSetupDroo.Controls.Add(this.tbxStopDroo);
            this.gbxSetupDroo.Controls.Add(this.btnGoDroo);
            this.gbxSetupDroo.Controls.Add(this.tbxStartDroo);
            this.gbxSetupDroo.Controls.Add(this.lblNumberOfAttemptsDroo);
            this.gbxSetupDroo.Controls.Add(this.lblStopAtDroo);
            this.gbxSetupDroo.Controls.Add(this.lblStartAtDroo);
            this.gbxSetupDroo.Location = new System.Drawing.Point(9, 12);
            this.gbxSetupDroo.Name = "gbxSetupDroo";
            this.gbxSetupDroo.Size = new System.Drawing.Size(291, 149);
            this.gbxSetupDroo.TabIndex = 0;
            this.gbxSetupDroo.TabStop = false;
            this.gbxSetupDroo.Text = "Setup";
            // 
            // btnDefaultDroo
            // 
            this.btnDefaultDroo.Location = new System.Drawing.Point(214, 104);
            this.btnDefaultDroo.Name = "btnDefaultDroo";
            this.btnDefaultDroo.Size = new System.Drawing.Size(71, 23);
            this.btnDefaultDroo.TabIndex = 9;
            this.btnDefaultDroo.Text = "Default";
            this.btnDefaultDroo.UseVisualStyleBackColor = true;
            this.btnDefaultDroo.Click += new System.EventHandler(this.btnDefaultDroo_Click);
            // 
            // tbxNumberOfAttemptsDroo
            // 
            this.tbxNumberOfAttemptsDroo.Location = new System.Drawing.Point(105, 101);
            this.tbxNumberOfAttemptsDroo.Name = "tbxNumberOfAttemptsDroo";
            this.tbxNumberOfAttemptsDroo.Size = new System.Drawing.Size(100, 20);
            this.tbxNumberOfAttemptsDroo.TabIndex = 8;
            // 
            // tbxStopDroo
            // 
            this.tbxStopDroo.Location = new System.Drawing.Point(105, 64);
            this.tbxStopDroo.Name = "tbxStopDroo";
            this.tbxStopDroo.Size = new System.Drawing.Size(100, 20);
            this.tbxStopDroo.TabIndex = 7;
            // 
            // btnGoDroo
            // 
            this.btnGoDroo.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnGoDroo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoDroo.Location = new System.Drawing.Point(214, 42);
            this.btnGoDroo.Name = "btnGoDroo";
            this.btnGoDroo.Size = new System.Drawing.Size(71, 61);
            this.btnGoDroo.TabIndex = 6;
            this.btnGoDroo.Text = "GO!";
            this.btnGoDroo.UseVisualStyleBackColor = true;
            this.btnGoDroo.Click += new System.EventHandler(this.btnGoDroo_Click);
            // 
            // tbxStartDroo
            // 
            this.tbxStartDroo.Location = new System.Drawing.Point(105, 26);
            this.tbxStartDroo.Name = "tbxStartDroo";
            this.tbxStartDroo.Size = new System.Drawing.Size(100, 20);
            this.tbxStartDroo.TabIndex = 3;
            // 
            // lblNumberOfAttemptsDroo
            // 
            this.lblNumberOfAttemptsDroo.AutoSize = true;
            this.lblNumberOfAttemptsDroo.Location = new System.Drawing.Point(3, 104);
            this.lblNumberOfAttemptsDroo.Name = "lblNumberOfAttemptsDroo";
            this.lblNumberOfAttemptsDroo.Size = new System.Drawing.Size(102, 13);
            this.lblNumberOfAttemptsDroo.TabIndex = 2;
            this.lblNumberOfAttemptsDroo.Text = "Number of attempts:";
            // 
            // lblStopAtDroo
            // 
            this.lblStopAtDroo.AutoSize = true;
            this.lblStopAtDroo.Location = new System.Drawing.Point(6, 67);
            this.lblStopAtDroo.Name = "lblStopAtDroo";
            this.lblStopAtDroo.Size = new System.Drawing.Size(44, 13);
            this.lblStopAtDroo.TabIndex = 1;
            this.lblStopAtDroo.Text = "Stop at:";
            // 
            // lblStartAtDroo
            // 
            this.lblStartAtDroo.AutoSize = true;
            this.lblStartAtDroo.Location = new System.Drawing.Point(6, 29);
            this.lblStartAtDroo.Name = "lblStartAtDroo";
            this.lblStartAtDroo.Size = new System.Drawing.Size(44, 13);
            this.lblStartAtDroo.TabIndex = 0;
            this.lblStartAtDroo.Text = "Start at:";
            // 
            // gbxPlayDroo
            // 
            this.gbxPlayDroo.Controls.Add(this.lblWrongGuessesDroo);
            this.gbxPlayDroo.Controls.Add(this.pgbWrongGuessesDroo);
            this.gbxPlayDroo.Controls.Add(this.pgbAttemptsLeftDroo);
            this.gbxPlayDroo.Controls.Add(this.lblColdDroo);
            this.gbxPlayDroo.Controls.Add(this.lblHotDroo);
            this.gbxPlayDroo.Controls.Add(this.tbHotColdDroo);
            this.gbxPlayDroo.Controls.Add(this.lblAttemptsLeftDroo);
            this.gbxPlayDroo.Controls.Add(this.btnGuessDroo);
            this.gbxPlayDroo.Controls.Add(this.tbxGuessDroo);
            this.gbxPlayDroo.Controls.Add(this.lblMyGuessDroo);
            this.gbxPlayDroo.Location = new System.Drawing.Point(9, 167);
            this.gbxPlayDroo.Name = "gbxPlayDroo";
            this.gbxPlayDroo.Size = new System.Drawing.Size(291, 160);
            this.gbxPlayDroo.TabIndex = 1;
            this.gbxPlayDroo.TabStop = false;
            this.gbxPlayDroo.Text = "Play";
            // 
            // lblWrongGuessesDroo
            // 
            this.lblWrongGuessesDroo.AutoSize = true;
            this.lblWrongGuessesDroo.Location = new System.Drawing.Point(5, 131);
            this.lblWrongGuessesDroo.Name = "lblWrongGuessesDroo";
            this.lblWrongGuessesDroo.Size = new System.Drawing.Size(84, 13);
            this.lblWrongGuessesDroo.TabIndex = 11;
            this.lblWrongGuessesDroo.Text = "Wrong guesses:";
            // 
            // pgbWrongGuessesDroo
            // 
            this.pgbWrongGuessesDroo.ForeColor = System.Drawing.Color.Lime;
            this.pgbWrongGuessesDroo.Location = new System.Drawing.Point(105, 132);
            this.pgbWrongGuessesDroo.Name = "pgbWrongGuessesDroo";
            this.pgbWrongGuessesDroo.Size = new System.Drawing.Size(100, 13);
            this.pgbWrongGuessesDroo.TabIndex = 10;
            // 
            // lblColdDroo
            // 
            this.lblColdDroo.AutoSize = true;
            this.lblColdDroo.Location = new System.Drawing.Point(228, 128);
            this.lblColdDroo.Name = "lblColdDroo";
            this.lblColdDroo.Size = new System.Drawing.Size(28, 13);
            this.lblColdDroo.TabIndex = 8;
            this.lblColdDroo.Text = "Cold";
            // 
            // lblHotDroo
            // 
            this.lblHotDroo.AutoSize = true;
            this.lblHotDroo.Location = new System.Drawing.Point(232, 16);
            this.lblHotDroo.Name = "lblHotDroo";
            this.lblHotDroo.Size = new System.Drawing.Size(24, 13);
            this.lblHotDroo.TabIndex = 7;
            this.lblHotDroo.Text = "Hot";
            // 
            // tbHotColdDroo
            // 
            this.tbHotColdDroo.Location = new System.Drawing.Point(231, 22);
            this.tbHotColdDroo.Name = "tbHotColdDroo";
            this.tbHotColdDroo.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tbHotColdDroo.Size = new System.Drawing.Size(45, 119);
            this.tbHotColdDroo.TabIndex = 6;
            // 
            // lblAttemptsLeftDroo
            // 
            this.lblAttemptsLeftDroo.AutoSize = true;
            this.lblAttemptsLeftDroo.Location = new System.Drawing.Point(3, 113);
            this.lblAttemptsLeftDroo.Name = "lblAttemptsLeftDroo";
            this.lblAttemptsLeftDroo.Size = new System.Drawing.Size(68, 13);
            this.lblAttemptsLeftDroo.TabIndex = 5;
            this.lblAttemptsLeftDroo.Text = "Attempts left:";
            // 
            // btnGuessDroo
            // 
            this.btnGuessDroo.Location = new System.Drawing.Point(115, 56);
            this.btnGuessDroo.Name = "btnGuessDroo";
            this.btnGuessDroo.Size = new System.Drawing.Size(80, 42);
            this.btnGuessDroo.TabIndex = 3;
            this.btnGuessDroo.Text = "Guess!";
            this.btnGuessDroo.UseVisualStyleBackColor = true;
            this.btnGuessDroo.Click += new System.EventHandler(this.btnguessdroo_Click);
            // 
            // tbxGuessDroo
            // 
            this.tbxGuessDroo.Location = new System.Drawing.Point(105, 19);
            this.tbxGuessDroo.Name = "tbxGuessDroo";
            this.tbxGuessDroo.Size = new System.Drawing.Size(100, 20);
            this.tbxGuessDroo.TabIndex = 1;
            // 
            // lblMyGuessDroo
            // 
            this.lblMyGuessDroo.AutoSize = true;
            this.lblMyGuessDroo.Location = new System.Drawing.Point(3, 26);
            this.lblMyGuessDroo.Name = "lblMyGuessDroo";
            this.lblMyGuessDroo.Size = new System.Drawing.Size(55, 13);
            this.lblMyGuessDroo.TabIndex = 0;
            this.lblMyGuessDroo.Text = "My guess:";
            // 
            // gbxInformationDroo
            // 
            this.gbxInformationDroo.Controls.Add(this.rtbInformationDroo);
            this.gbxInformationDroo.Location = new System.Drawing.Point(9, 343);
            this.gbxInformationDroo.Name = "gbxInformationDroo";
            this.gbxInformationDroo.Size = new System.Drawing.Size(291, 157);
            this.gbxInformationDroo.TabIndex = 2;
            this.gbxInformationDroo.TabStop = false;
            this.gbxInformationDroo.Text = "Information";
            // 
            // rtbInformationDroo
            // 
            this.rtbInformationDroo.Location = new System.Drawing.Point(3, 18);
            this.rtbInformationDroo.Name = "rtbInformationDroo";
            this.rtbInformationDroo.Size = new System.Drawing.Size(282, 132);
            this.rtbInformationDroo.TabIndex = 10;
            this.rtbInformationDroo.Text = "";
            // 
            // btnAboutDroo
            // 
            this.btnAboutDroo.Location = new System.Drawing.Point(21, 506);
            this.btnAboutDroo.Name = "btnAboutDroo";
            this.btnAboutDroo.Size = new System.Drawing.Size(58, 23);
            this.btnAboutDroo.TabIndex = 3;
            this.btnAboutDroo.Text = "About";
            this.btnAboutDroo.UseVisualStyleBackColor = true;
            this.btnAboutDroo.Click += new System.EventHandler(this.btnaboutdroo_Click);
            // 
            // btnLocateDroo
            // 
            this.btnLocateDroo.Location = new System.Drawing.Point(85, 506);
            this.btnLocateDroo.Name = "btnLocateDroo";
            this.btnLocateDroo.Size = new System.Drawing.Size(62, 23);
            this.btnLocateDroo.TabIndex = 4;
            this.btnLocateDroo.Text = "Locate";
            this.btnLocateDroo.UseVisualStyleBackColor = true;
            this.btnLocateDroo.Click += new System.EventHandler(this.btnlocatedroo_Click);
            // 
            // btnCheatDroo
            // 
            this.btnCheatDroo.Location = new System.Drawing.Point(151, 506);
            this.btnCheatDroo.Name = "btnCheatDroo";
            this.btnCheatDroo.Size = new System.Drawing.Size(63, 23);
            this.btnCheatDroo.TabIndex = 5;
            this.btnCheatDroo.Text = "Cheat";
            this.btnCheatDroo.UseVisualStyleBackColor = true;
            this.btnCheatDroo.Click += new System.EventHandler(this.btncheatdroo_Click);
            // 
            // btnClearDroo
            // 
            this.btnClearDroo.Location = new System.Drawing.Point(220, 506);
            this.btnClearDroo.Name = "btnClearDroo";
            this.btnClearDroo.Size = new System.Drawing.Size(66, 23);
            this.btnClearDroo.TabIndex = 6;
            this.btnClearDroo.Text = "Clear";
            this.btnClearDroo.UseVisualStyleBackColor = true;
            this.btnClearDroo.Click += new System.EventHandler(this.btncleardroo_Click);
            // 
            // btnMovingPictureDroo
            // 
            this.btnMovingPictureDroo.Location = new System.Drawing.Point(419, 493);
            this.btnMovingPictureDroo.Name = "btnMovingPictureDroo";
            this.btnMovingPictureDroo.Size = new System.Drawing.Size(121, 53);
            this.btnMovingPictureDroo.TabIndex = 8;
            this.btnMovingPictureDroo.Text = "Start!";
            this.btnMovingPictureDroo.UseVisualStyleBackColor = true;
            this.btnMovingPictureDroo.Click += new System.EventHandler(this.btnMovingPictureDroo_Click);
            // 
            // btnShowGameDroo
            // 
            this.btnShowGameDroo.Location = new System.Drawing.Point(737, 491);
            this.btnShowGameDroo.Name = "btnShowGameDroo";
            this.btnShowGameDroo.Size = new System.Drawing.Size(121, 53);
            this.btnShowGameDroo.TabIndex = 11;
            this.btnShowGameDroo.Text = "Show the game!";
            this.btnShowGameDroo.UseVisualStyleBackColor = true;
            this.btnShowGameDroo.Click += new System.EventHandler(this.btnShowGameDroo_Click);
            // 
            // tbxEnterYourNameDroo
            // 
            this.tbxEnterYourNameDroo.Location = new System.Drawing.Point(708, 235);
            this.tbxEnterYourNameDroo.Name = "tbxEnterYourNameDroo";
            this.tbxEnterYourNameDroo.Size = new System.Drawing.Size(161, 20);
            this.tbxEnterYourNameDroo.TabIndex = 12;
            // 
            // lblNameDroo
            // 
            this.lblNameDroo.AutoSize = true;
            this.lblNameDroo.Location = new System.Drawing.Point(748, 219);
            this.lblNameDroo.Name = "lblNameDroo";
            this.lblNameDroo.Size = new System.Drawing.Size(87, 13);
            this.lblNameDroo.TabIndex = 13;
            this.lblNameDroo.Text = "Enter your name:";
            // 
            // btnSubmitDroo
            // 
            this.btnSubmitDroo.Location = new System.Drawing.Point(754, 259);
            this.btnSubmitDroo.Name = "btnSubmitDroo";
            this.btnSubmitDroo.Size = new System.Drawing.Size(75, 23);
            this.btnSubmitDroo.TabIndex = 14;
            this.btnSubmitDroo.Text = "Submit";
            this.btnSubmitDroo.UseVisualStyleBackColor = true;
            this.btnSubmitDroo.Click += new System.EventHandler(this.btnSubmitDroo_Click);
            // 
            // lblMadeByDroo
            // 
            this.lblMadeByDroo.AutoSize = true;
            this.lblMadeByDroo.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMadeByDroo.Location = new System.Drawing.Point(341, 76);
            this.lblMadeByDroo.Name = "lblMadeByDroo";
            this.lblMadeByDroo.Size = new System.Drawing.Size(286, 37);
            this.lblMadeByDroo.TabIndex = 15;
            this.lblMadeByDroo.Text = "Daphne van Rooij";
            // 
            // pbxYouLoseDroo
            // 
            this.pbxYouLoseDroo.BackgroundImage = global::Mysterynumber_daphnevanrooij.Properties.Resources._360_F_529761687_w6ZgCR7oJ8iyoPofo8hPikOw6EM9cp4m;
            this.pbxYouLoseDroo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYouLoseDroo.Location = new System.Drawing.Point(1292, 167);
            this.pbxYouLoseDroo.Name = "pbxYouLoseDroo";
            this.pbxYouLoseDroo.Size = new System.Drawing.Size(303, 201);
            this.pbxYouLoseDroo.TabIndex = 18;
            this.pbxYouLoseDroo.TabStop = false;
            // 
            // pbxYouWinDroo
            // 
            this.pbxYouWinDroo.BackgroundImage = global::Mysterynumber_daphnevanrooij.Properties.Resources._360_F_312815843_CdVm05kiBenU3YmChP1KRIzcblRgTQFV;
            this.pbxYouWinDroo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxYouWinDroo.Location = new System.Drawing.Point(977, 140);
            this.pbxYouWinDroo.Name = "pbxYouWinDroo";
            this.pbxYouWinDroo.Size = new System.Drawing.Size(302, 247);
            this.pbxYouWinDroo.TabIndex = 16;
            this.pbxYouWinDroo.TabStop = false;
            // 
            // pbxMovingPicture3Droo
            // 
            this.pbxMovingPicture3Droo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxMovingPicture3Droo.Image = global::Mysterynumber_daphnevanrooij.Properties.Resources._7761dfa10ecbd295d95d19ce59ab947e;
            this.pbxMovingPicture3Droo.Location = new System.Drawing.Point(962, -2);
            this.pbxMovingPicture3Droo.Name = "pbxMovingPicture3Droo";
            this.pbxMovingPicture3Droo.Size = new System.Drawing.Size(324, 562);
            this.pbxMovingPicture3Droo.TabIndex = 17;
            this.pbxMovingPicture3Droo.TabStop = false;
            // 
            // pbxMovingpicture2Droo
            // 
            this.pbxMovingpicture2Droo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxMovingpicture2Droo.Image = global::Mysterynumber_daphnevanrooij.Properties.Resources._7761dfa10ecbd295d95d19ce59ab947e;
            this.pbxMovingpicture2Droo.Location = new System.Drawing.Point(639, -2);
            this.pbxMovingpicture2Droo.Name = "pbxMovingpicture2Droo";
            this.pbxMovingpicture2Droo.Size = new System.Drawing.Size(324, 562);
            this.pbxMovingpicture2Droo.TabIndex = 10;
            this.pbxMovingpicture2Droo.TabStop = false;
            // 
            // pbxMovingPictureDroo
            // 
            this.pbxMovingPictureDroo.Image = global::Mysterynumber_daphnevanrooij.Properties.Resources.unnamed;
            this.pbxMovingPictureDroo.Location = new System.Drawing.Point(323, -4);
            this.pbxMovingPictureDroo.Name = "pbxMovingPictureDroo";
            this.pbxMovingPictureDroo.Size = new System.Drawing.Size(324, 562);
            this.pbxMovingPictureDroo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxMovingPictureDroo.TabIndex = 7;
            this.pbxMovingPictureDroo.TabStop = false;
            // 
            // pbxBackgroundDroo
            // 
            this.pbxBackgroundDroo.Image = global::Mysterynumber_daphnevanrooij.Properties.Resources._7761dfa10ecbd295d95d19ce59ab947e;
            this.pbxBackgroundDroo.Location = new System.Drawing.Point(-1, -3);
            this.pbxBackgroundDroo.Name = "pbxBackgroundDroo";
            this.pbxBackgroundDroo.Size = new System.Drawing.Size(324, 562);
            this.pbxBackgroundDroo.TabIndex = 9;
            this.pbxBackgroundDroo.TabStop = false;
            // 
            // pbxMovingPicture4Droo
            // 
            this.pbxMovingPicture4Droo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbxMovingPicture4Droo.Image = global::Mysterynumber_daphnevanrooij.Properties.Resources._7761dfa10ecbd295d95d19ce59ab947e;
            this.pbxMovingPicture4Droo.Location = new System.Drawing.Point(1285, -3);
            this.pbxMovingPicture4Droo.Name = "pbxMovingPicture4Droo";
            this.pbxMovingPicture4Droo.Size = new System.Drawing.Size(324, 562);
            this.pbxMovingPicture4Droo.TabIndex = 19;
            this.pbxMovingPicture4Droo.TabStop = false;
            // 
            // Form1Droo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(1604, 558);
            this.Controls.Add(this.btnMovingPictureDroo);
            this.Controls.Add(this.pbxYouLoseDroo);
            this.Controls.Add(this.pbxMovingPicture4Droo);
            this.Controls.Add(this.pbxYouWinDroo);
            this.Controls.Add(this.pbxMovingPicture3Droo);
            this.Controls.Add(this.lblMadeByDroo);
            this.Controls.Add(this.btnSubmitDroo);
            this.Controls.Add(this.lblNameDroo);
            this.Controls.Add(this.tbxEnterYourNameDroo);
            this.Controls.Add(this.btnShowGameDroo);
            this.Controls.Add(this.pbxMovingpicture2Droo);
            this.Controls.Add(this.pbxMovingPictureDroo);
            this.Controls.Add(this.btnClearDroo);
            this.Controls.Add(this.btnCheatDroo);
            this.Controls.Add(this.btnLocateDroo);
            this.Controls.Add(this.btnAboutDroo);
            this.Controls.Add(this.gbxInformationDroo);
            this.Controls.Add(this.gbxPlayDroo);
            this.Controls.Add(this.gbxSetupDroo);
            this.Controls.Add(this.pbxBackgroundDroo);
            this.Name = "Form1Droo";
            this.Text = "Form1Droo";
            this.Load += new System.EventHandler(this.Form1Droo_Load);
            this.gbxSetupDroo.ResumeLayout(false);
            this.gbxSetupDroo.PerformLayout();
            this.gbxPlayDroo.ResumeLayout(false);
            this.gbxPlayDroo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbHotColdDroo)).EndInit();
            this.gbxInformationDroo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxYouLoseDroo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxYouWinDroo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingPicture3Droo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingpicture2Droo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingPictureDroo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBackgroundDroo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxMovingPicture4Droo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxSetupDroo;
        private System.Windows.Forms.Label lblNumberOfAttemptsDroo;
        private System.Windows.Forms.Label lblStopAtDroo;
        private System.Windows.Forms.Label lblStartAtDroo;
        private System.Windows.Forms.Button btnGoDroo;
        private System.Windows.Forms.TextBox tbxStartDroo;
        private System.Windows.Forms.GroupBox gbxPlayDroo;
        private System.Windows.Forms.TextBox tbxGuessDroo;
        private System.Windows.Forms.Label lblMyGuessDroo;
        private System.Windows.Forms.TrackBar tbHotColdDroo;
        private System.Windows.Forms.Label lblAttemptsLeftDroo;
        private System.Windows.Forms.Button btnGuessDroo;
        private System.Windows.Forms.Label lblColdDroo;
        private System.Windows.Forms.Label lblHotDroo;
        private System.Windows.Forms.GroupBox gbxInformationDroo;
        private System.Windows.Forms.PictureBox pbxMovingPictureDroo;
        private System.Windows.Forms.Button btnMovingPictureDroo;
        private System.Windows.Forms.Button btnCheatDroo;
        private System.Windows.Forms.Button btnClearDroo;
        private System.Windows.Forms.Button btnAboutDroo;
        private System.Windows.Forms.TextBox tbxStopDroo;
        private System.Windows.Forms.RichTextBox rtbInformationDroo;
        private System.Windows.Forms.TextBox tbxNumberOfAttemptsDroo;
        private System.Windows.Forms.ProgressBar pgbAttemptsLeftDroo;
        private System.Windows.Forms.Button btnLocateDroo;
        private System.Windows.Forms.PictureBox pbxBackgroundDroo;
        private System.Windows.Forms.PictureBox pbxMovingpicture2Droo;
        private System.Windows.Forms.Button btnShowGameDroo;
        private System.Windows.Forms.TextBox tbxEnterYourNameDroo;
        private System.Windows.Forms.Label lblNameDroo;
        private System.Windows.Forms.Button btnSubmitDroo;
        private System.Windows.Forms.Label lblMadeByDroo;
        private System.Windows.Forms.PictureBox pbxYouWinDroo;
        private System.Windows.Forms.PictureBox pbxMovingPicture3Droo;
        private System.Windows.Forms.PictureBox pbxYouLoseDroo;
        private System.Windows.Forms.PictureBox pbxMovingPicture4Droo;
        private System.Windows.Forms.Button btnDefaultDroo;
        private System.Windows.Forms.Label lblWrongGuessesDroo;
        private System.Windows.Forms.ProgressBar pgbWrongGuessesDroo;
    }
}

